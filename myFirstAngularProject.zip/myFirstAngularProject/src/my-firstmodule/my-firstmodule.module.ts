import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyFirstcomponentComponent } from './my-firstcomponent/my-firstcomponent.component';



@NgModule({
  declarations: [
    MyFirstcomponentComponent
  ],
  imports: [
    CommonModule
  ]
})
export class MyFirstmoduleModule { }
