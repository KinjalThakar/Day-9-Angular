import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateTimeFormatPipe'
})

export class DateTimeFormatPipe extends DatePipe implements PipeTransform {
  override transform(value: any, format = ''): any {
    if (format) {
      return super.transform(value, format);
    } else {
      // Default format
      return super.transform(value, 'MM/dd/yyyy hh:mm:ss a');
    }
  }
}
